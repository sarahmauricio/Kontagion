#include "StudentWorld.h"
#include "GameConstants.h"
#include <string>
#include "Actor.h"
#include<cmath>
#include <cstdlib>
#include <sstream>
#include<iomanip>
using namespace std;

GameWorld* createStudentWorld(string assetPath)
{
	return new StudentWorld(assetPath);
}

// Students:  Add code to this file, StudentWorld.h, Actor.h and Actor.cpp

StudentWorld::StudentWorld(string assetPath)
	: GameWorld(assetPath)
{
	m_isComplete = false;
	m_isPitEmpty = false;
}

int StudentWorld::init()
{
	int level = getLevel();
	m_socrates = new Socrates(this);
	int i = 0;
	while (i <= 0) {
		int xd = randInt(0, VIEW_WIDTH);
		int yd = randInt(0, VIEW_WIDTH);
		if (sqrt(pow(xd - VIEW_WIDTH / 2, 2) + pow(yd - VIEW_HEIGHT / 2, 2)) < 120) {
			myActorVector.push_back(new Pit(xd, yd, this));
			i = 1;
		}
		else
			i--;
	}

	if (level > 1)
	{
		for (int i = 1; i < level; i++)
		{
			int xd = randInt(0, VIEW_WIDTH);
			int yd = randInt(0, VIEW_WIDTH);

			for (int i = 0; i < myActorVector.size(); i++)
			{
				if (overlap(xd, yd, myActorVector[i]->getX(), myActorVector[i]->getY()) == true)
					i--;
				else
					if (sqrt(pow(xd - VIEW_WIDTH / 2, 2) + pow(yd - VIEW_HEIGHT / 2, 2)) < 120)
						myActorVector.push_back(new Pit(xd, yd, this));
					else
						i--;
			}
		}
	}

	//int numOfActors = myActorVector.size();

	for (int i = 0; i < max(180 - 20 * level, 20); i++)
	{
		int xd = randInt(0, VIEW_WIDTH);
		int yd = randInt(0, VIEW_WIDTH);
		if (sqrt(pow(xd - VIEW_WIDTH / 2, 2) + pow(yd - VIEW_HEIGHT / 2, 2)) < 120)
			myActorVector.push_back(new Dirt(xd, yd, this));
		else
			i--;
		/*
		int xd = randInt(0, VIEW_WIDTH);
		int yd = randInt(0, VIEW_WIDTH);
		for (int i = 0; i < numOfActors; i++)
		{
			if (overlap(xd, yd, myActorVector[i]->getX(), myActorVector[i]->getY()) == true)
				i--;
			else {
				if (sqrt(pow(xd - VIEW_WIDTH / 2, 2) + pow(yd - VIEW_HEIGHT / 2, 2)) < 120)
					myActorVector.push_back(new Dirt(xd, yd, this));
				else
					i--;
			}
		}
		*/
	}


	return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld::move()
{
	//int level = getLevel();
	// This code is here merely to allow the game to build, run, and terminate after you hit enter.
	// Notice that the return value GWSTATUS_PLAYER_DIED will cause our framework to end the current level.
   // decLives();
	m_socrates->doSomething();
	for (int i = 0; i < myActorVector.size(); i++)
	{
		myActorVector[i]->doSomething();
		if (m_socrates->getAlive() == false)
		{
			decLives();

			delete m_socrates;
			return GWSTATUS_PLAYER_DIED;
		}
		if (isComplete() == true) // --> need to figure out if there is more than one pit and if all the bacteria has died
			return GWSTATUS_FINISHED_LEVEL;
	}


	for (int i = 0; i < myActorVector.size(); i++)
	{
		if (myActorVector[i]->getAlive() == false) {
			delete myActorVector[i];
			myActorVector.erase(myActorVector.begin() + i);
		}
	}

	//add new actors to game
	/*
	double PI = 3.14159;
	int chanceFungus = max(510 - level * 10, 200);
	int rando = randInt(0, chanceFungus - 1);
	if (rando == 0) 
	{
		int random = rand()* 360 * VIEW_RADIUS;
		random = (random / 180) * PI;
		int xd = VIEW_RADIUS * cos(random) + 128;
		int yd = VIEW_RADIUS * sin(random) + 128;
		myActorVector.push_back(new Fungus(xd, yd, this));
	}
	*/
/*
	int chanceGoodie = max(510 - getLevel() * 10, 250);
	int rando2 = randInt(0, chanceGoodie - 1);
	if (rando2 == 0)
	{
		int random = rand() * 360 * VIEW_RADIUS;
		random = (random / 180) * PI;
		int xd = VIEW_RADIUS * cos(random) + 128;
		int yd = VIEW_RADIUS * sin(random) + 128;
		int randomAngle = randInt(0, 360);
		//make it a random angle

		int rando3 = randInt(1, 10);
		if (rando3 <= 6)
			myActorVector.push_back(new RestoreHealth(xd, yd, this));
		else if (rando3>6 && rando3 <=9)
			myActorVector.push_back(new FlameThrower(xd, yd, this));
		else if(rando3 == 10)
			myActorVector.push_back(new ExtraLife(xd, yd, this));

		
		
	}	
	*/
	

	ostringstream oss;
	oss << "Score: " << setw(1) << getScore() << setw(1) << "  ";
	oss << "Level: " << setw(1) << getLevel() << setw(1) << "  ";
	oss << "Lives: " << setw(1) << getLives() << setw(1) << "  ";
	oss << "Health: " << setw(1) << getSocrates()->getHitPoints() << setw(1) << "  ";
	oss << "Sprays: " << setw(1) << getSocrates()->getSprayCharges() << setw(1) << "  ";
	oss << "Flames: " << setw(1) << getSocrates()->getFlameThrower() << setw(1) << "  ";
	string s = oss.str();
	setGameStatText(s);

	return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::cleanUp()
{
	for (int i = 0; i < myActorVector.size();)
	{
		delete myActorVector[i];
		myActorVector.erase(myActorVector.begin());
	}
}

StudentWorld::~StudentWorld()
{
	cleanUp();
}


void StudentWorld::addActor(Actor* a)
{
	myActorVector.push_back(a);
}

Socrates* StudentWorld::getSocrates() {
	return m_socrates;
}

void StudentWorld::setCompleted() {
	m_isComplete = true;
}

bool StudentWorld::isComplete()
{
	return m_isComplete;
}

bool StudentWorld::overlap(int x1, int y1, int x2, int y2) {
	if (abs(x1 - x2) < SPRITE_WIDTH && abs(y1 - y2) < SPRITE_WIDTH)
		return true;
	else
		return false;
}
/*
bool StudentWorld::overlap2(int x, int y)
{

}
*/
bool StudentWorld::pitEmpty() {
	return m_isPitEmpty;
}
void StudentWorld::setPitEmpty() {
	m_isPitEmpty = true;
}