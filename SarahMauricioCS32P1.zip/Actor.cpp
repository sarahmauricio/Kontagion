#include "Actor.h"
#include "StudentWorld.h"
#include <cmath>

// Students:  Add code to this file, Actor.h, StudentWorld.h, and StudentWorld.cpp

/////////////ACTOR IMPLEMENTATIONS/////////////

Actor::Actor(int mid, bool alive, int x, int y, Direction mdirection, int mdepth, StudentWorld* myStudentWorld, int hitPoints) : GraphObject(mid, x, y, mdirection, mdepth, 1)
{
	m_studentWorld = myStudentWorld;
	m_direction = mdirection;
	m_hitPoints = hitPoints;
	m_alive = alive;
}
void Actor::setAlive(bool alive) {
	m_alive = alive;
}

bool Actor::getAlive() {
	return m_alive;
}

int Actor::getHitPoints() {
	return m_hitPoints;
}

void Actor::updateHitPoints(int points) { // need to fix
	int x = getStudentWorld()->getSocrates()->getHitPoints();
	if (x + points < 100)
		m_hitPoints += points;
	else
		m_hitPoints = 100;
}

int Actor::returnMax(int a, int b)
{
	if (a > b)
		return a;
	else
		return b;
}

double Actor::distanceFromSocrates(int x, int y)
{
	double xx = abs(getStudentWorld()->getSocrates()->getX() - x);
	double yy = abs(getStudentWorld()->getSocrates()->getY() - y);
	double distance = sqrt(pow(xx, 2) + pow(yy, 2));
	return distance;
}

bool Actor::overlapsWithSocrates(double x, double y) { //need to fix

	
	double distance = distanceFromSocrates(x, y);
	if (distance <= SPRITE_RADIUS/2)
	{
		return true;
	}
	else
		return false;
		
	/*if (abs(getStudentWorld()->getSocrates()->getX()- x) <= SPRITE_RADIUS/2  && abs(getStudentWorld()->getSocrates()->getY() -y) <= SPRITE_RADIUS/2)
		return true;
	else
		return false;*/
}


/////////////SOCRATES IMPLEMENTATIONS/////////////
Socrates::Socrates(StudentWorld* myStudentWorld) : Actor(IID_PLAYER, true, 0, 128, 0, 0, myStudentWorld, 100)
{
	m_sprayCharges = 20;
	m_flameThrowerCharges = 5;
	m_angle = 5;
}

void Socrates::updateFlameThrower(int num) {
	m_flameThrowerCharges += num;
}

int Socrates:: getFlameThrower()
{ 
	return m_flameThrowerCharges; 
}

int Socrates::getSprayCharges()
{ 
	return m_sprayCharges; 
}
void Socrates::setSprayCharges(int num)
{
	m_sprayCharges += num;
}

bool Socrates::canBlock() {
	return false;
}

bool Socrates::canBeDamaged() {
	return true;
}

void Socrates::movement(Direction d) {
	double PI = 4 * atan(1);
	double x = VIEW_WIDTH / 2 + VIEW_RADIUS * (cos((d + 180) * 1.0 * PI / 180));
	double y = VIEW_WIDTH / 2 + VIEW_RADIUS * (sin((d + 180) * 1.0 * PI / 180));
	moveTo(x, y);
	setDirection(d);
}

void Socrates::doSomething()
{
	if (getHitPoints() <= 0)
	{
		getStudentWorld()->playSound(SOUND_PLAYER_DIE);
		setAlive(false);
		return;
	}
	int ch;
	Direction d = getDirection();
	Flame* f;
	Spray* sp;
	
	if (getStudentWorld()->getKey(ch)) {
		switch (ch)
		{
		case KEY_PRESS_LEFT:
			d += 5;
			movement (d);
			// move counterclockwise
			
			break;
		case KEY_PRESS_RIGHT:
			d -= 5;
			movement(d);
			
			//move clockwise
			break;
		case KEY_PRESS_SPACE:
			if (m_sprayCharges >= 1)
			{
			sp = new Spray(getX(), getY(), d, getStudentWorld());
			getStudentWorld()->addActor(sp);
			sp->moveAngle(d, 2 * SPRITE_RADIUS);
			setSprayCharges(-1);
			getStudentWorld()->playSound(SOUND_PLAYER_SPRAY);

			}
			else
				return;
			break;
		case KEY_PRESS_ENTER:
			if (m_flameThrowerCharges >= 1)
			{
				//add 16 spray object
			for (int i = 0; i < 16; i++)
			{
				f = new Flame(getX(), getY(), d, getStudentWorld());
				getStudentWorld()->addActor(f);
				f->moveAngle(d, 2 * SPRITE_RADIUS);
				d += 22;
			}
			updateFlameThrower(-1);
			getStudentWorld()->playSound(SOUND_PLAYER_FIRE);
			}
			else
					return;
			break;
		default:
			break;
		}
	}
	else
	{
		if (getSprayCharges() < 20)
			setSprayCharges(1);
	}

}


/////////////DIRT IMPLEMENTATIONS/////////////

Dirt::Dirt(int dirtX, int dirtY, StudentWorld* myStudentWorld) : Actor(IID_DIRT, true, dirtX, dirtY, 0, 1, myStudentWorld, 0)
{

}

bool Dirt::canBlock() {
	return true;
}
bool Dirt::canBeDamaged() {
	return true;
}

/////////////PROJECTILE IMPLEMENTATIONS/////////////

Projectile::Projectile(int mid, bool alive, int proX, int proY, Direction dir, int depth, StudentWorld* myStudentWorld, int maxTravel, int decAmount) : Actor(mid, alive, proX, proY, dir, depth, myStudentWorld, 0)
{
	m_movement = 0;
	m_maxTravel = maxTravel;
	m_decAmount = decAmount;
}

void Projectile::doSomething() {
	if (getAlive() == false)
		return;
	else if (0)//it overlaps with a dameageable object)
	{
		//tell impacted object it was damaged with decAmount hit points
		setAlive(false);
		return;
	}
	else
	{
		moveAngle(getDirection(), SPRITE_RADIUS * 2);
		m_movement += SPRITE_RADIUS * 2;
		if (m_movement == m_maxTravel)
			setAlive(false);
	}
}

bool Projectile::canBlock() {
	return false;
}

bool Projectile::canBeDamaged() {
	return false;
}

/////////////FLAME IMPLEMENTATIONS/////////////

Flame::Flame(int flameX, int flameY, Direction dir, StudentWorld* myStudentWorld) : Projectile(IID_FLAME, true, flameX, flameY, dir, 1, myStudentWorld, 32, 5)
{

}


/////////////SPRAY IMPLEMENTATIONS/////////////

Spray::Spray(int sprayX, int sprayY, Direction dir, StudentWorld* myStudentWorld) : Projectile(IID_SPRAY, true, sprayX, sprayY, dir, 1, myStudentWorld, 112, 2)
{

}

/////////////FOOD IMPLEMENTATIONS/////////////

Food::Food(int foodX, int foodY, StudentWorld* myStudentWorld) : Actor(IID_FOOD, true, foodX, foodY, 90, 1, myStudentWorld, 0) {

}

bool Food::canBlock() {
	return false;
}

bool Food::canBeDamaged() {
	return false;
}

/////////////GOODIE IMPLEMENTATIONS/////////////

Goodie::Goodie(int mid, bool alive, int gooX, int gooY, Direction dir, int depth, int lifetime, StudentWorld* myStudentWorld, int hitPoints, int updatePoints) : Actor(mid, alive, gooX, gooY, dir, depth, myStudentWorld, hitPoints)
{
	m_lifetime = lifetime;
	m_updatePoints = updatePoints;
	m_ticks = 0;
}

void Goodie::doSomething() {
	if (getAlive() == false)
		return;
	else if(overlapsWithSocrates(getX(), getY()) == true) //overlaps with Socrates
	{
		getStudentWorld()->increaseScore(m_updatePoints);
		setAlive(false);
		getStudentWorld()->playSound(SOUND_GOT_GOODIE);
		doDifferent();
		return;
	}
	if (m_ticks > m_lifetime) {
		setAlive(false);
	}
	m_ticks++;
	
}

bool Goodie::canBlock() {
	return false;
}

bool Goodie::canBeDamaged() {
	return true;
}

/////////////RESTORE HEALTH IMPLEMENTATIONS/////////////

RestoreHealth::RestoreHealth(int rhX, int rhY, StudentWorld* myStudentWorld) : Goodie(IID_RESTORE_HEALTH_GOODIE, true, rhX, rhY, 0, 1, returnMax(rand() % (300 - 10 * getStudentWorld()->getLevel()), 50), myStudentWorld, 0, 250)
{

}

void RestoreHealth::doDifferent() {
	getStudentWorld()->getSocrates()->updateHitPoints(100);
}

/////////////EXTRA LIFE IMPLEMENTATIONS/////////////

ExtraLife::ExtraLife(int elX, int elY, StudentWorld* myStudentWorld) : Goodie(IID_EXTRA_LIFE_GOODIE, true, elX, elY, 0, 1, returnMax(rand() % (300 - 10 * getStudentWorld()->getLevel()), 50), myStudentWorld, 0, 500)
{

}

void ExtraLife::doDifferent() {
	getStudentWorld()->incLives();
}

/////////////FLAME THROWER IMPLEMENTATIONS/////////////

FlameThrower::FlameThrower(int flX, int flY, StudentWorld* myStudentWorld) : Goodie(IID_FLAME_THROWER_GOODIE, true, flX, flY, 0, 1, returnMax(rand() % (300 - 10 * getStudentWorld()->getLevel()), 50), myStudentWorld, 0, 300)
{

}
void FlameThrower::doDifferent() {
	getStudentWorld()->getSocrates()->updateFlameThrower(5);
}

/////////////BACTERIA IMPLEMENTATIONS/////////////

Bacteria::Bacteria(int mid, bool alive, int bacX, int bacY, Direction dir, int depth, StudentWorld* myStudentWorld, int hitPoints, int movementPlanDistance, int damagePoints) : Actor(mid, alive, bacX, bacY, dir, depth, myStudentWorld, hitPoints)
{
	m_movementPlanDistance = movementPlanDistance;
	m_foodEaten = 0;
	m_damagePoints = damagePoints;
}

void Bacteria:: doSomething() {
	if (getAlive() == false) //step 1
		return;
	bool b = true;

	if (overlapsWithSocrates(getX(), getY()) == true) //overlaps with socrates --> step 2
	{
		getStudentWorld()->getSocrates()->updateHitPoints(m_damagePoints);
	}
	else if (m_foodEaten == 3) // step 3
	{
		int newX = getX();
		if (newX > VIEW_WIDTH / 2)
			newX -= SPRITE_RADIUS;
		else
			newX += SPRITE_RADIUS;
		int newY = getY();
		if (newY > VIEW_WIDTH / 2)
			newY -= SPRITE_RADIUS;
		else
			newY += SPRITE_RADIUS;
		addNewActor(newX, newY);
		m_foodEaten = 0;
	}
	else if (0) //overlaps with 1+ food objects --> step 4
	{
		m_foodEaten++;
		//set one food object state to dead
	}
	if (b == true)
		doDifferent1(m_movementPlanDistance);
	else
		return;
	
}

bool Bacteria::canBlock() {
	return false;
}

bool Bacteria::canBeDamaged() {
	return true;
}


/////////////SALMONELLA IMPLEMENTATIONS/////////////
Salmonella ::Salmonella(int mid, int salX, int salY, StudentWorld* myStudentWorld, int hitPoints, int damagePoints) : Bacteria(mid, true, salX, salY, 90, 0, myStudentWorld, hitPoints, 0, damagePoints)
{

}

void Salmonella :: doDifferent1(int& movementPlanDistance)
{
	if (movementPlanDistance > 0) //step 5
	{
		movementPlanDistance--;
		if (0) //can't move forward 3 pixels its currently facing
		{
			setDirection(randInt(0, 359));
			movementPlanDistance = 10;
		}
		else
			moveAngle(getDirection(), 3);
		return;
	}
	else //step 6
	{
		if (0) // no food found within 128 pixels
		{
			setDirection(randInt(0, 359));
			movementPlanDistance = 10;
			return;
		}
		else
		{
			if (0)//move 3 pixels toward food overlaps with dirt
			{
				setDirection(randInt(0, 359));
				movementPlanDistance = 10;
				return;
			}
			else
			{
				// move 3 pixels in direction of food
			}
		}
	}
}

/////////////REGULAR SALMONELLA IMPLEMENTATIONS/////////////

RSalmonella::RSalmonella(int rSalX, int rSalY, StudentWorld* myStudentWorld) : Salmonella(IID_SALMONELLA, rSalX, rSalY, myStudentWorld, 4, -1)
{

}

void RSalmonella::addNewActor(int x, int y) {
	RSalmonella* rSalmonella = new RSalmonella(x, y, getStudentWorld()); 
	getStudentWorld()->addActor(rSalmonella); 
}

/////////////AGGRESSIVE SALMONELLA IMPLEMENTATIONS/////////////

ASalmonella::ASalmonella(int aSalX, int aSalY, StudentWorld* myStudentWorld) : Salmonella(IID_SALMONELLA, aSalX, aSalY, myStudentWorld, 10, -2)
{

}

void ASalmonella::aSalmonellaDifferent(bool& a) {
	if (distanceFromSocrates(getX(), getY())<= 72) // <= 72 pixels away from socrates
	{
		//move forward in direction of socrates
		if (0) //gets blocked by dirt
		{
			//will not move
		}
		a = false;
	}
}

void ASalmonella::addNewActor(int x, int y) {
	ASalmonella* aSalmonella = new ASalmonella(x, y, getStudentWorld());
	getStudentWorld()->addActor(aSalmonella); 
}

/////////////E COLI IMPLEMENTATIONS/////////////

EColi::EColi(int eColiX, int eColiY, StudentWorld* myStudentWorld) : Bacteria(IID_ECOLI, true, eColiX, eColiY, 90, 0, myStudentWorld, 5, 0, -4)
{

}

void EColi::doDifferent1(int & movementPlanDistance)
{
	movementPlanDistance = movementPlanDistance;
	if (distanceFromSocrates(getX(), getY()) <= 256) //less than or equal to 256 pixels away from socrates
	{
		//get directional angle theta toward socrates
		for (int i = 0; i < 10; i++)
		{
			if (0)//ecoli blocked by dirt moving 2 pixels toward socrates
			{
				/*
				if (theta += 10 >= 360)
				{
					theta -= 360;
				}
				else
					theta+= 10*/
			}
			else
			{
				//move forward 2 pixels in direction of socrates
				return;
			}
		}
		return;
	}
}

void EColi::addNewActor(int x, int y) {
	EColi* eColi = new EColi(x, y, getStudentWorld()); 
	getStudentWorld()->addActor(eColi); 
}

/////////////FUNGUS IMPLEMENTATIONS/////////////

Fungus::Fungus(int fungusX, int fungusY, StudentWorld* myStudentWorld) : Actor(IID_FUNGUS, true, fungusX, fungusY, 0, 1, myStudentWorld, 0)
{
	m_ticks = 0;
	m_lifetime = returnMax(randInt(0, 300 - 10 * getStudentWorld()->getLevel() - 1), 50);
}

void Fungus::doSomething() {
	/*
	if (getAlive() == false)
		return;
	if (overlapsWithSocrates(getX(), getY())==true) //overlaps with socrates
	{
		getStudentWorld()->increaseScore(-50);
		setAlive(false);
		getStudentWorld()->getSocrates()->updateHitPoints(-20);
		if (getStudentWorld()->getSocrates()->getHitPoints() > 0)
			getStudentWorld()->playSound(SOUND_PLAYER_HURT);
		return;
	}
	if (m_ticks >= m_lifetime) //lifetime has expired 
		setAlive(false);
	m_ticks++;
	*/
}

bool Fungus::canBlock() {
	return false;
}

bool Fungus::canBeDamaged() {
	return true;
}

/////////////PIT IMPLEMENTATIONS/////////////

Pit::Pit(int pitX, int pitY, StudentWorld* myStudentWorld) : Actor(IID_PIT, true, pitX, pitY, 0, 1, myStudentWorld, 0)
{
	m_numOfASalmonella = 3;
	m_numOfEColi = 2;
	m_numOfRSalmonella = 5;
	m_x = pitX;
	m_y = pitY;
}
void Pit::doSomething() {
	if (m_numOfASalmonella == 0 && m_numOfEColi == 0 && m_numOfRSalmonella == 0)
	{
		getStudentWorld()->setPitEmpty();
		setAlive(false);
	}
	else
	{
		int randI = randInt(1, 50);
		if (randI == 40)
		{
			bool okay = false;
			while (okay == false) {
				int x = randInt(1, 3);
				if (x == 1) {
					if (m_numOfASalmonella > 0)
					{
						okay = true;
						ASalmonella* aSalmonella = new ASalmonella(m_x, m_y, getStudentWorld());
						getStudentWorld()->addActor(aSalmonella);
						m_numOfASalmonella--;
						getStudentWorld()->playSound(SOUND_BACTERIUM_BORN);
						//getStudentWorld()->getSocrates()->updateHitPoints(100);
						//getStudentWorld()->getSocrates()->setAlive(false);
					}
				}
				if (x == 1) {
					if (m_numOfEColi > 0)
					{
						okay = true;
						EColi* eColi = new EColi(m_x, m_y, getStudentWorld());
						getStudentWorld()->addActor(eColi);
						m_numOfEColi--;
						getStudentWorld()->playSound(SOUND_BACTERIUM_BORN);
					}
				}
				if (x == 2) {
					if (m_numOfRSalmonella > 0)
					{
						okay = true;
						RSalmonella* rSalmonella = new RSalmonella(m_x, m_y, getStudentWorld());
						getStudentWorld()->addActor(rSalmonella);
						m_numOfRSalmonella--;
						getStudentWorld()->playSound(SOUND_BACTERIUM_BORN);
					}
				}
			}
		}
	}
}

bool Pit::canBlock() {
	return false;
}

bool Pit::canBeDamaged() {
	return false;
}